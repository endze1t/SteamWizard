/**
 *
 * @author Ahmed
 * Mar 11, 2017
 *
 */

var STEAMWIZARD_VERSION = "1.0.1";

require.config({
    baseUrl: "/javascript",
    waitSeconds : 60,
    urlArgs: STEAMWIZARD_VERSION
});